/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Objetos;

/**
 *
 * @author josep
 */
public class Admin extends Persona{
    
    private String contrasena;

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }
    
    public boolean verificacionContrasena(String contrasena)
    {
    /*int contadorCaracteres = 0;
    int contadorNumeros = 0;
    int contadorSpecial = 0;
    for(int i = 0;i < contrasena.length(); i++){
        
    }*/
        
    }
    

    @Override
    public String toString() {
        return "Admin{" + "contrasena=" + contrasena + '}';
    }
    
    
    
    
    
}
